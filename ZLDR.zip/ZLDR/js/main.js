
$(function () {

    $(".btn-search").click(function(e){
        e.preventDefault();
        $(this).closest(".form-search").addClass("open");
        $('#search-input').focus();
    });

    $(".close-search").click(function(e){
        e.preventDefault();
        $(this).closest(".form-search").removeClass("open");
    });

    $(".dropdown-calenader > a").click(function(e){
        e.preventDefault();
        $('.dropdown-menu-c').toggleClass("open");
    });

    $(".diapazon-btn a").click(function(e){
        e.preventDefault();
        $('.box-calendar').toggleClass("open");
    });

    $(".calendar-close").click(function(e){
        e.preventDefault();
        $('.box-calendar').removeClass("open");
    });

    $(".cl-calendar").click(function(e){
        e.preventDefault();
        $(".box-calendar").removeClass('open');
        $(".dropdown-menu-c").removeClass('open');
    });

    $(".calendar-drop .item a").click(function(e){
        e.preventDefault();
        $('.calendar-drop .item').removeClass("active");
        $(this).closest('.item').addClass("active");
    });

    $('.slick-slider').slick({
      dots: true,
      infinite: true,
      autoplay: false,
      autoplaySpeed: 2000
    });
    $('.slider-similar-news').slick({
        speed: 300,
        arrows: true,
        prevArrow: "<button type='button' class='slick-arrow slick-prev'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
        nextArrow: "<button type='button' class='slick-arrow slick-next'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $('#mobile-menu-trigger').click(function () {
      $(this).toggleClass('open');
      $('.mobile-menu').toggleClass('active');
    });

    $('.has-submenu').click(function () {
      $(this).toggleClass('submenu-active');
    });

    if ($('*').is('.mobile-table')){
        $(".aside-table, .payment").stacktable();
    }

    $('#datetimepicker12').datetimepicker({
        inline: true,
        locale: 'ru',
        format: 'DD.MM.YYYY'
    });
    $('#datetimepicker13').datetimepicker({
        inline: true,
        locale: 'ru',
        format: 'DD.MM.YYYY'
    });





});

$(document).on('click', '.calendar-finish', function(event) {
    event.preventDefault();
    $(".box-calendar").removeClass('open');
    $(".calendar-drop").removeClass('open');
    $(".input-first").text($('#datetimepicker12 input').val());
    $(".input-second").text($('#datetimepicker13 input').val());
    $(this).closest('.dropdown').removeClass("open");
});